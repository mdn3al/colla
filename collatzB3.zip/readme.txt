
We start yhe Collatz function with 10221 in base 3 witch means 106 in base 10

We didn't implemented no procedures to devide by 2, so we used addition to double a number and manualy implement Collatz oprations.


